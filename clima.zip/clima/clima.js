const paragrahp = document.getElementById('paragraph')
const loadP = document.getElementById('loadP');
const loader = document.getElementsByClassName('lds-roller'); ('lds-roller');
const inputCity = document.getElementById('inputCity')
const btnSearch = document.getElementById('btnSearch')
const nameCountry = document.getElementById('nameCountry');
const city = document.getElementById('city');
const humidity= document.getElementById('humidity');
const pressure = document.getElementById('pressure');
const temp = document.getElementById('temp');
const temp_min = document.getElementById('temp_min');
const temp_max = document.getElementById('temp_max');
const icon = document.getElementsByTagName('img')
const APIKEY = '27eb21bb24bdac7f2b991492589c704c';
const openWeather = async (city) => {
    const getDataFromAPIWeather = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${APIKEY}`)
    const responseData = await getDataFromAPIWeather.json();
    return responseData;
}





btnSearch.addEventListener('click', () => {
    loader[0].classList.add('show')
    
    openWeather(inputCity.value)
        .then((respuestaDelClima) => {
            loader[0].classList.remove('show');
            loader[0].classList.add('none');
            console.log(respuestaDelClima)
            nameCountry.innerText = 'Pais:'+ respuestaDelClima.sys.country;
            city.innerText ='Ciudad:'+ respuestaDelClima.name;
            humidity.innerText = 'Humedad: ' + respuestaDelClima.main.humidity;
            pressure.innerText = 'Presion: mbar ' + respuestaDelClima.main.pressure;
            temp.innerText = 'Temperatura:°C ' + Math.round((respuestaDelClima.main.temp)-273.15)
            temp_min.innerText = 'Temperatura MIN:°C ' + Math.round((respuestaDelClima.main.temp_min)-273.15)
            temp_max.innerText = 'Temperatura MAX:°C ' + Math.round((respuestaDelClima.main.temp_max)-273.15)
           

            const iconWeather = respuestaDelClima.weather[0].icon;
            icon[0].setAttribute('src',`https://openweathermap.org/img/wn/${iconWeather}@2x.png`)
            

        })
        .catch((error) => console.log(error));

})

console.log(inputCity.value)
/*console.log(loader)*/
/*setTimeout(() => {
    loadP.classList.remove('show');
    loader[0].style.display = 'none';


}, 3000)*/





